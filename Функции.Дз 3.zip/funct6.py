def int_func (*args):
    word = input("Input words ")
    print(word.title())
    return
int_func()
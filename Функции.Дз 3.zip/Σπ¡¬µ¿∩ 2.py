 name = input('enter name')
    surname = input('enter surname')
    year = int(input('enter year'))
    city = input('enter city')
    email = input('enter email')
    telephone = input('input telephone')
'''
def my_func (name, surname, year, city, email, telephone):
     return ' '.join([name, surname, year, city, email, telephone])
print(my_func(surname = 'Frolov', name = 'Andrey', year = '1997', city = 'Syzran', email = '32332@mail.ru', telephone = '8-912-300-99-87'))